import React from "react";
import { Routes } from "./Components/Route/Routes"

const App = () => {

  return (
    <div>
      <Routes />
    </div>
  );
}


export default App;
