

export function BrowseHeader(params) {

    return (
        <>
            <div>
                <h1>
                    Browse Fundraisers
                </h1>
                <h3>
                    Choose from 1,50,256 fundraisers to support
                </h3>
            </div>
        </>
    )

}