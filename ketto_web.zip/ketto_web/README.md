npm install 
npm start 
go to http://localhost:3000/fundraiser

only Sticky header Update 7 december  other done 